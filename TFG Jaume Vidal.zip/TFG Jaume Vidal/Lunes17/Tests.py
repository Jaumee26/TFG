import time,csv

def fastTest(stopEvent,osc,awg, **params):
        inicio = float(params['inicio'])
        periodo = inicio
        amplitud= float(params['amplitud'])
        paso = float(params['paso'])
        fin = float(params['fin'])
        duty = float(params['duty'])
        offset=0
        if params['tipo']=='Diferencial':
            offset=amplitud/2
        fname= "./tests/fastTest"+time.strftime('%H%M%S')+'.csv'
        with open(fname, "w", newline='') as f:
            wr = csv.writer(f, dialect='excel')    
            wr.writerow(['canal','num','periodo','duty','medida','mMean','mStdev','amplitude','rms','numero'])
        pasos = int((fin - inicio) / paso)
        osc.trigMode='AUTO'
        osc.ch3.vdiv = 1
        osc.ch4.vdiv = 1
        osc.ch3.trigLevel = amplitud/2
        osc.ch4.trigLevel = amplitud/2
        osc.parameterSetup('WID',1,3)
        osc.write('PACU 6,DDLY,C3,C4') 
        osc.write('C3:TRA ON') 
        osc.opComplete()
        awg.ch1.config('PULSe',1,'TRIGgered','INFinity')
        awg.ch2.config('PULSe',1,'TRIGgered','INFinity')
        awg.run()
        for i in range (0,pasos,1):
            data=[]
            t=float(periodo+(paso*i))
            awg.ch1.pulseValue(amplitud,offset,duty,t,0.8e-9,0.8e-9)
            awg.ch2.pulseValue(amplitud,offset,duty,t,0.8e-9,0.8e-9)
            osc.opComplete()
            awg.trigger()
            osc.tdiv(t)    
            osc.trigMode='AUTO'
            time.sleep(5)   
            osc.trigMode='STOP'
            dataC3=osc.query('C3:PAVA? ').split(',')
            statC3=osc.query('PAST? CUST,P1 ').split(',')
            data=['C3',i,t,duty,dataC3[28],statC3[5],statC3[13],dataC3[1],dataC3[22],statC3[15].rstrip("\n")]
            with open(fname, "a", newline='') as f:
                wr = csv.writer(f, dialect='excel')    
                wr.writerow(data)
            if stopEvent.is_set():
                break
        osc.trigMode='AUTO'
        awg.stop()
        awg.close()
        osc.close()

    
def slowTest(stopEvent,osc,awg, **params):
        inicio = float(params['inicio'])
        periodo = inicio
        amplitud= float(params['amplitud'])
        paso = float(params['paso'])
        fin = float(params['fin'])
        duty = float(params['duty'])
        offset=0
        if params['tipo']=='Diferencial':
            offset=amplitud/2
        fname= "./tests/slowTest"+time.strftime('%H%M%S')+'.csv'
        with open(fname, "w", newline='') as f:
            wr = csv.writer(f, dialect='excel')    
            wr.writerow(['canal','num','periodo','duty','medida','mMean','mStdev','retardo','rMean','rStdev','amplitude','rms','numero'])
        pasos = int((fin - inicio) / paso)
        ciclos= 10
        osc.trigMode='AUTO'
        osc.ch3.vdiv = 1
        osc.ch4.vdiv = 1
        osc.ch3.trigLevel = amplitud/2
        osc.ch4.trigLevel = amplitud/2
        osc.parameterSetup('WID',1,3)
        osc.parameterSetup('WID',2,4)
        osc.write('PACU 6,DDLY,C3,C4') 
        osc.write('C3:TRA ON') 
        osc.write('C4:TRA ON') 
        osc.opComplete()
        awg.ch1.config('PULSe',1,'TRIGgered',10)
        awg.ch2.config('PULSe',1,'TRIGgered',10)
        awg.run()
        for i in range (0,pasos,1):
            data=[]
            t=float(periodo+(paso*i))
            awg.ch1.pulseValue(amplitud,offset,duty,t,0.8e-9,0.8e-9)
            awg.ch2.pulseValue(amplitud,offset,duty,t,0.8e-9,0.8e-9)
            osc.tdiv(t)    
            for j in range(0,ciclos):
                osc.trigMode='SINGLE'
                awg.trigger()
                osc.opComplete()
                dataC3=osc.query('C3:PAVA? ').split(',')
                dataC4=osc.query('C4:PAVA? ').split(',')
                delay=osc.query('PAVA? DLY ').split(',')[1]
                statC3=osc.query('PAST? CUST,P1 ').split(',')
                statC4=osc.query('PAST? CUST,P2 ').split(',')
                statDelay=osc.query('PAST? CUST,P6 ').split(',')
                data.append(['C3',j,t,duty,dataC3[28],statC3[5],statC3[13],delay,statDelay[5],statDelay[13],dataC3[1],dataC3[22],statC3[15].rstrip("\n")])
                data.append(['C4',j,t,duty,dataC4[28],statC4[5],statC4[13],delay,statDelay[5],statDelay[13],dataC4[1],dataC4[22],statC4[15].rstrip("\n")])
            with open(fname, "a", newline='') as f:
                for measure in data:
                    wr = csv.writer(f, dialect='excel')    
                    wr.writerow(measure)
            if stopEvent.is_set():
                break
        osc.trigMode='AUTO'
        awg.stop()
        awg.close()
        osc.close()
