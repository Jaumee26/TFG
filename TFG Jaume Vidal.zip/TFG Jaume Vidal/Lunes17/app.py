from flask import Flask, render_template, request 
import threading, os

import LeCroyWaveRunner, ArbRiderAFG
from Analisis import analisis
from Tests import fastTest, slowTest

app = Flask(__name__)
 
stop_event = threading.Event()
path = './tests/'   


@app.route('/',methods=['GET', 'POST'])
def index():

    if request.method == 'POST':
        parameters = dict(request.form)
        if parameters['action'] == 'iniciar': #Leer los datos de los parametros para iniciar test
            try:
                stop_event.clear()
                osc= LeCroyWaveRunner.WaveRunner('VICP::147.156.52.47')
                awg = ArbRiderAFG.ArbRider('TCPIP::147.156.53.71::INSTR')
                if parameters.get('test') == 'fast':
                    thread = threading.Thread(target=fastTest, args=(stop_event,osc,awg), kwargs=parameters)
                else:
                    thread = threading.Thread(target=slowTest, args=(stop_event,osc,awg), kwargs=parameters)      
                thread.start()
            except:
                    print('No se ha podido establecer conexion con los equipos')
        elif  parameters['action'] == 'detener': # Parar la ejecucion del test
            stop_event.set()
 
        elif  parameters['action'] == 'analizar': # Analizar los resultados
            if parameters.get('filename') != None:
                    analisis(parameters)
 

    files = [f for f in os.listdir(path) if f.endswith('.csv')]
    return render_template('index.html', files=files)        

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000)
