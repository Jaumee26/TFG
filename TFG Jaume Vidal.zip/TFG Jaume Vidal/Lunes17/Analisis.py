import matplotlib
matplotlib.use('Agg') 
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

def analisis(parameters):
    df = pd.read_csv('./tests/'+parameters['filename'])

    if not df.empty:        
        sns.set_theme(style="whitegrid")
        # Gráfico 2 
        plt.figure(figsize=(8, 5))
        sns.kdeplot(data=df, x="mStdev", hue="canal")
        plt.savefig('./static/kdeplot.png')
        plt.close()
        # Gráfico 3 
        plt.figure(figsize=(8, 5))
        sns.lineplot(data=df, x="mMean", y="mStdev")
        plt.savefig('./static/lineplot.png')
        plt.close()