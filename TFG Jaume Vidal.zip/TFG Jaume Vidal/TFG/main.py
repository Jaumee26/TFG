import LeCroyWaveRunner, ArbRiderAFG
import matplotlib.pyplot as plt
import numpy as np
import time, csv

fname= "output"+time.strftime('%H%M')+'.csv'
osc= LeCroyWaveRunner.WaveRunner('VICP::147.156.52.47')
awg = ArbRiderAFG.ArbRider('TCPIP::147.156.53.71::INSTR')

periodo= 10e-9
voltaje= 0.5
offset = 0.25
ciclos = 500
duty= 50
final = 100e-3
incremento = 5e-9
TDIV = periodo
inicio = periodo
pasos = int((final - inicio) / incremento)

osc.trigMode='AUTO'
osc.ch3.vdiv=0.5
osc.ch4.vdiv=0.5
osc.ch3.trigLevel=0.5
osc.ch4.trigLevel=0.5
osc.parameterSetup('WID',1,3)
osc.parameterSetup('WID',2,4)
osc.write('PACU 6,DDLY,C3,C4') 

awg.ch1.config('PULSe','TRIGgered',1)
awg.ch2.config('PULSe','TRIGgered',1)
awg.run()


with open(fname, "w", newline='') as f:
    wr = csv.writer(f, dialect='excel')    
    wr.writerow(['canal','num','periodo','duty','medida','retardo','mean','stdev','amplitude','rms'])

for i in range (0,pasos,1):
    data=[]
    dataC3=[]
    dataC4=[]
    t=float(periodo+(incremento*i))
    awg.ch1.pulseValue(1,voltaje,offset,duty,t,0.8e-9,0.8e-9)
    awg.ch2.pulseValue(1,voltaje,offset,duty,t,0.8e-9,0.8e-9)
    osc.tdiv(t)    
    for i in range(0,ciclos):
        osc.trigMode='SINGLE'
        time.sleep(0.2)
        awg.trigger()
        time.sleep(0.1)
        osc.opComplete()
        dataC3=osc.query('C3:PAVA? ').split(',')
        dataC4=osc.query('C4:PAVA? ').split(',')
        delay=osc.query('PAVA? DLY ').split(',')[1]
        data.append(['C3',i,t,duty,dataC3[28],delay,dataC3[10],dataC3[25],dataC3[1],dataC3[22]])
        data.append(['C4',i,t,duty,dataC4[28],delay,dataC4[10],dataC4[25],dataC4[1],dataC4[22]])
    with open(fname, "a", newline='') as f:
        for measure in data:
            wr = csv.writer(f, dialect='excel')    
            wr.writerow(measure)


awg.stop()
awg.close()
osc.close()